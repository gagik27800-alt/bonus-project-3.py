import time
import sys

def start_timer(total_seconds):
    """
    Counts down from the given number of seconds and prints to the terminal.
    """
    print(f"Timer started for {total_seconds} seconds...\n")
    
    while total_seconds >= 0:

        mins, secs = divmod(total_seconds, 60)

        timer_display = f"{mins:02d}:{secs:02d}"
        
        print(f"\rTime Remaining: {timer_display}", end="")
        
       
        time.sleep(1)
        sys.stdout.flush()
        total_seconds -= 1
        if total_seconds < 0:
            break

    print("\n\nTime's up!")

if __name__ == "__main__":
    try:
        user_input = int(input("Enter the time in seconds: "))
        start_timer(user_input)
    except ValueError:
        print("Invalid input! Please enter a whole number of seconds.")